package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.EmployeeRepositoryDAO;
import com.cg.dao.EmployeeRepositoryDAOImpl;
import com.cg.entities.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepositoryDAO employeeRepositoryDAO;
	@Override
	public Employee save(Employee employee) {
		return employeeRepositoryDAO.save(employee);
	}

	@Override
	public List<Employee> loadAll() {
		return employeeRepositoryDAO.loadAll();
	}

}
